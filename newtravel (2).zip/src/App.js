import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Login from './component/pages/Login';
import Register from './component/pages/Register';
import Home from './component/Home';
import Hotel from './component/Hotel';
import Destination from './component/Destination';
import Tour from './component/Tour';
import Flight from './component/Flight';
import Navbar from './component/Navbar';
import Navbar2 from './component/Navbar2';
import "./App.css"
import Tabss from './component/Tabss';
import Footer from './component/Footer';
import Header from './component/Header';
import HotelList from './component/HotelList';
import AboutUs from './component/AboutUs';
import HotelDetails from './component/HotelDetails';
import '../src/main.css'

function App() {
  return (
    <div>


      <BrowserRouter>
        {/* <Navbar /> */}
        <Header />

        <Routes>

          <Route path='/' element={<Home />} />
          <Route path='/Flight' element={<Flight />} />
          <Route path='/Hotel' element={<Hotel />} />
          <Route path='/Destination' element={< Destination />} />
          <Route path='/Tour' element={<Tour />} />
          <Route path='/Login' element={<Login />} />
          <Route path='/Register' element={<Register />} />
          <Route path='/Tabss' element={<Tabss />} />
          <Route path='/Footer' element={<Footer />} />
          <Route path='/HotelList' element={<HotelList />} />
          <Route path='/AboutUs' element={<AboutUs />} />
          <Route path='/HotelDetails/:id' element={<HotelDetails />} />








        </Routes>
      </BrowserRouter>


    </div>
  );
}

export default App;
