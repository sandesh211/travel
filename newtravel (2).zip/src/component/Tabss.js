import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import DropdownButton from 'react-bootstrap/DropdownButton';
import Datepicker from "react-tailwindcss-datepicker";
import 'react-bootstrap';
import axios from 'axios';
import Country from './Country.json'


const Tabss = () => {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState(1);
    const [allCities, setAllCities] = useState([]);
    const [cityvalue, setCityValue] = useState("");
    const [cityvalD, setCityValD] = useState("");
    const [cityFilterValue, setCityFilterValue] = useState([]);
    const [cityFilterValueDest, setCityFilterValueDest] = useState([]);
    const [selectnationlity, setSelectnationlity] = useState('');
    const [selectedRatings, setSelectedRatings] = useState([]);
    const [isShown, setIsShown] = useState(false);
    const [isShowns, setIsShowns] = useState(false);
    const [isShownD, setIsShownD] = useState(false);
    const [adults, setAdults] = useState(0);
    const [children, setChildren] = useState(0);
    const [rooms, setRooms] = useState(0);
    const [setid, setSetid] = useState('');
    const [startDate, setStartDate] = useState('')
    const [endDate, setEndDate] = useState('')
    const [selectedDates, setSelectedDates] = useState({ startDate: null, endDate: null });





    const handleshow = event => {

        if (isShown == false) {
            setIsShown(true)

        } else {
            setIsShown(false)
        }
    };

    const handleshows = event => {
        if (isShowns == false) {
            setIsShowns(true)

        } else {
            setIsShowns(false)
        }
    };




    const handleAdultsDecrement = () => {
        if (adults > 0) {
            setAdults(adults - 1);
        }
    };

    const handleAdultsIncrement = () => {
        setAdults(adults + 1);
    };

    const handleChildrenDecrement = () => {
        if (children > 0) {
            setChildren(children - 1);
        }
    };

    const handleChildrenIncrement = () => {
        setChildren(children + 1);
    };

    const handleRoomsDecrement = () => {
        if (rooms > 0) {
            setRooms(rooms - 1);
        }
    };

    const handleRoomsIncrement = () => {
        setRooms(rooms + 1);
    };

    const tabs = [
        { title: 'Tab 1', content: 'This is the content for Tab 1' },
        { title: 'Tab 2', content: 'This is the content for Tab 2' },
        { title: 'Tab 3', content: 'This is the content for Tab 3' },
    ];

    const handleValueChangedate = (value) => {
        if (value.startDate && value.endDate) {
            setSelectedDates({ startDate: value.startDate, endDate: value.endDate });
            setStartDate(value.startDate);
            setEndDate(value.endDate);

        }
    };



    const handleRatingChange = (event) => {
        const rating = event.target.value;
        if (event.target.checked) {
            setSelectedRatings(prevRatings => [...prevRatings, rating]);
        } else {
            setSelectedRatings(prevRatings => prevRatings.filter(prevRating => prevRating !== rating));

        }
    }


    const handleCountryChange = (event) => {
        const selectedCountryName = event.target.value;
        const selectedCountry = Country.find(country => country.name === selectedCountryName);
    }
    const handleChangeNationlity = (event) => {
        const selectedCountryName = event.target.value;
        const selectedCountry = Country.find(country => country.name === selectedCountryName);
        setSelectnationlity(selectedCountry?.countryid);


    }


    const handleTabClick = (tabIndex) => {
        setActiveTab(tabIndex);
    };




    const [value, setValue] = useState({
        startDate: new Date(),
        endDate: new Date().setMonth(11)

    });
    const Searchlist = () => {
        const apikey = "7121268d836907-c712-4301-81f3-bf819f0c159f";
        let config = {
            apikey: "7121268d836907-c712-4301-81f3-bf819f0c159f"
        }
        const searchQuery = {
            searchQuery: {
                checkinDate: startDate,
                checkoutDate: endDate,
                roomInfo: [
                    {
                        numberOfAdults: adults,
                        numberOfChild: children,
                        childAge: [6]
                    }
                ],
                searchCriteria: {
                    city: "740051",
                    // city: setid.toString(),
                    nationality: selectnationlity,
                    currency: "INR"
                },
                searchPreferences: {
                    ratings:
                        selectedRatings
                    ,
                    fsc: true
                }
            },
            sync: true
        };
        const newConfig = {
            'Content-Type': 'application/json ',
            apikey: apikey

        }
        const data = JSON.stringify(searchQuery)
        axios.post("https://apitest.tripjack.com/hms/v1/hotel-searchquery-list", data, { headers: newConfig })
            .then((response) => {
                console.log("response", response);
                navigate('/HotelList', { state: { data: response.data } });
            })
            .catch((error) => {
                console.log("error", error.message);
            });

    }









    function getAllCities() {
        const apikey = "7121268d836907-c712-4301-81f3-bf819f0c159f";
        let config = {
            apikey: "7121268d836907-c712-4301-81f3-bf819f0c159f"
        };
        axios.get("https://apitest.tripjack.com/hms/v1/static-cities/", {
            headers: config,
        }).then((res) => {

            setAllCities(res?.data?.response?.cil);
        }).catch((err) => { console.log("error", err); });
    }

    const handleChangeCity = (val) => {
        setCityValue(val)
        const newData = allCities.filter((data) => data.cityName.includes(val))
        setCityFilterValue(newData)
    }

    const handleChangeCityDest = (val) => {
        setCityValD(val)
        const newData = allCities.filter((data) => data.cityName.includes(val))
        setCityFilterValueDest(newData)
    }


    const handleCitySelect = (val) => {
        setCityValue(val?.cityName);
        setCityValD(val?.cityName);
        setSetid(val?.id)

    };
    const handleCitySelectD = (val) => {
        const newData = allCities.filter((data) => data.cityName.includes(val))
        setCityFilterValueDest(newData?.cil?.id)
        console.log("newData", newData);
    };

    useEffect(() => {
        getAllCities();
    }, []);

    const subitLocation = (e, data) => {


        handleCitySelectD(data);
    }


    return (
        <div className="flightcontainer">
            <main>
                <section className="topspace relative z-5">
                    <div className="container mx-auto container-xl">
                        <div className="row justify-center">
                            <div className="col-xl-12">
                                <div className="text-center">
                                    <h1 className="text-60 lg:text-40 md:text-30 text-white">Discover Your World</h1>
                                    <p className="text-white mt-5">Discover amzaing places at exclusive deals</p>
                                </div>
                                <div className="tabs_category">
                                    <div className="tabs__controlssdf">

                                        <button
                                            className={activeTab === 1 ? "active tabs__button px-30 py-20 rounded-4 fw-600 text-white js-tabs-button is-tab-el-active" : ""}
                                            onClick={() => handleTabClick(1)}
                                        >Flights

                                        </button>
                                        <button
                                            className={activeTab === 2 ? "active tabs__button px-30 py-20 rounded-4 fw-600 text-white js-tabs-button" : ""}
                                            onClick={() => handleTabClick(2)}
                                        >
                                            Tour
                                        </button>
                                        <button
                                            className={activeTab === 3 ? "active tabs__button px-30 py-20 rounded-4 fw-600 text-white js-tabs-button" : ""}
                                            onClick={() => handleTabClick(3)}
                                        >
                                            Hotel
                                        </button>
                                    </div>
                                    <div className="tab-content">
                                        {activeTab === 1 && <div class="button-grid items-center">
                                            <div class="tabs__pane -tab-item-1 is-tab-el-active">
                                                <div class="mainSearch bg-white pr-20 py-20 lg:px-20 lg:pt-5 lg:pb-20 rounded-4 shadow-1">
                                                    <div class="button-grid items-center grid-colams">

                                                        <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch -is-dd-wrap-active">

                                                            <div data-x-dd-click="searchMenu-loc">
                                                                <h4 class="text-15 fw-500 ls-2 lh-16">Location</h4>

                                                                <div class="text-15 text-light-1 ls-2 lh-16">
                                                                    <input
                                                                        type="text"
                                                                        value={cityvalue}
                                                                        onChange={(e) => {
                                                                            handleChangeCity(e.target.value);
                                                                        }}
                                                                        placeholder="Where are you going?"
                                                                        class="js-search js-dd-focus"
                                                                    />
                                                                </div>
                                                            </div>
                                                            {cityFilterValue && cityFilterValue.length > 0 &&
                                                                <div class="searchMenu-loc__field shadow-2 js-popup-window -is-active" data-x-dd="searchMenu-loc" data-x-dd-toggle="-is-active">
                                                                    <div class="bg-white px-30 py-30 sm:px-0 sm:py-15 rounded-4">
                                                                        <div class="y-gap-5 js-results">

                                                                            <div className="cityDataScroll">
                                                                                {
                                                                                    cityFilterValue?.map((data) => {
                                                                                        return (
                                                                                            <button key={data.cityName} class="-link d-block col-12 text-left rounded-4 px-20 py-15 js-search-option"
                                                                                             onClick={(e) => { e.stopPropagation(); handleCitySelect(data); setCityFilterValue(null) }}>
                                                                                                <div class="d-flex">
                                                                                                    <div class="icon-location-2 text-light-1 text-20 pt-4"></div>
                                                                                                    <div class="ml-10">
                                                                                                        <div class="text-15 lh-12 fw-500 js-search-option-target">{data.cityName}</div>
                                                                                                        <div class="text-14 lh-12 text-light-1 mt-5">{data.countryName}
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </button>
                                                                                        )
                                                                                    })
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>}
                                                        </div>

                                                        <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch">

                                                            <div data-x-dd-click="searchMenu-loc">
                                                                <h4 class="text-15 fw-500 ls-2 lh-16">Destination</h4>

                                                                <div class="text-15 text-light-1 ls-2 lh-16">
                                                                    <input
                                                                        type="text"
                                                                        value={cityvalD}
                                                                        onChange={(e) => {
                                                                            handleChangeCityDest(e.target.value)
                                                                        }}
                                                                        placeholder="Where are you going?"
                                                                        class="js-search js-dd-focus"
                                                                    />
                                                                </div>

                                                            </div>
                                                            {cityFilterValueDest && cityFilterValueDest.length > 0 &&
                                                                <div class="searchMenu-loc__field shadow-2 js-popup-window -is-active" data-x-dd="searchMenu-loc" data-x-dd-toggle="-is-active">
                                                                    <div class="bg-white px-30 py-30 sm:px-0 sm:py-15 rounded-4">
                                                                        <div class="y-gap-5 js-results">

                                                                            <div className="cityDataScroll">
                                                                                {
                                                                                    cityFilterValueDest?.map((data) => {
                                                                                        return (
                                                                                            <button key={data.cityName} class="-link d-block col-12 text-left rounded-4 px-20 py-15 js-search-option" onClick={(e) => {
                                                                                                subitLocation(e, data); setCityFilterValueDest(null)
                                                                                            }}>
                                                                                                <div class="d-flex">
                                                                                                    <div class="icon-location-2 text-light-1 text-20 pt-4"></div>
                                                                                                    <div class="ml-10">
                                                                                                        <div class="text-15 lh-12 fw-500 js-search-option-target">{data.cityName}</div>
                                                                                                        <div class="text-14 lh-12 text-light-1 mt-5">{data.countryName}
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </button>
                                                                                        )
                                                                                    })
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>}
                                                        </div>
                                                        <div class="searchMenu-date px-30 lg:py-20 lg:px-0 js-form-dd js-calendar">

                                                            <div data-x-dd-click="searchMenu-date">
                                                                <h4 class="text-15 fw-500 ls-2 lh-16">Check in - Check out</h4>
                                                                <div>
                                                                    <Datepicker classNames="date_width" value={{ startDate: selectedDates.startDate, endDate: selectedDates.endDate }} onChange={handleValueChangedate} />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="searchMenu-guests px-30 lg:py-20 lg:px-0 js-form-dd js-form-counters">

                                                            <div data-x-dd-click="searchMenu-guests">
                                                                <h4 class="text-15 fw-500 ls-2 lh-16" >Guest</h4>


                                                                <div class="text-15 text-light-1 ls-2 lh-16" onClick={handleshow}>
                                                                    <span class="js-count-adult">{adults}</span> adults {" "}
                                                                    <span class="js-count-child">{children}</span> children {" "}
                                                                    <span class="js-count-room">{rooms}</span> rooms
                                                                </div>

                                                            </div>
                                                            {isShown ?
                                                                <div class="searchMenu-guests__field shadow-2 -is-active" data-x-dd="searchMenu-guests" data-x-dd-toggle="-is-active">
                                                                    <div class="bg-white px-30 py-30 rounded-4">
                                                                        <div class="row y-gap-10 justify-between items-center">
                                                                            <div class="col-auto">
                                                                                <div class="text-15 fw-500">Adults</div>
                                                                            </div>

                                                                            <div class="col-auto">
                                                                                <div class="d-flex items-center js-counter" data-value-change=".js-count-adult">
                                                                                    <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleAdultsDecrement}>
                                                                                        <i class="icon-minus text-12"></i>
                                                                                    </button>

                                                                                    <div class="flex-center size-20 ml-15 mr-15">
                                                                                        <div class="text-15 js-count">{adults}</div>
                                                                                    </div>

                                                                                    <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleAdultsIncrement}>
                                                                                        <i class="icon-plus text-12"></i>
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                        <div class="border-top-light mt-24 mb-24"></div>

                                                                        <div class="row y-gap-10 justify-between items-center">
                                                                            <div class="col-auto">
                                                                                <div class="text-15 lh-12 fw-500">Children</div>

                                                                            </div>

                                                                            <div class="col-auto">
                                                                                <div class="d-flex items-center js-counter" data-value-change=".js-count-child">
                                                                                    <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleChildrenDecrement}>
                                                                                        <i class="icon-minus text-12"></i>
                                                                                    </button>

                                                                                    <div class="flex-center size-20 ml-15 mr-15">
                                                                                        <div class="text-15 js-count">{children}</div>
                                                                                    </div>

                                                                                    <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleChildrenIncrement}>
                                                                                        <i class="icon-plus text-12"></i>
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                        <div class="border-top-light mt-24 mb-24"></div>

                                                                        <div class="row y-gap-10 justify-between items-center">
                                                                            <div class="col-auto">
                                                                                <div class="text-15 fw-500">Rooms</div>
                                                                            </div>

                                                                            <div class="col-auto">
                                                                                <div class="d-flex items-center js-counter" data-value-change=".js-count-room">
                                                                                    <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleRoomsDecrement}>
                                                                                        <i class="icon-minus text-12"></i>
                                                                                    </button>

                                                                                    <div class="flex-center size-20 ml-15 mr-15">
                                                                                        <div class="text-15 js-count">{rooms}</div>
                                                                                    </div>

                                                                                    <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleRoomsIncrement}>
                                                                                        <i class="icon-plus text-12"></i>
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div> : null
                                                            }
                                                        </div>
                                                        <div class="button-item">
                                                            <button class="mainSearch__submit button -dark-1 py-15 px-35 h-60 col-12 rounded-4 bg-blue-1 text-white">
                                                                <i class="icon-search text-20 mr-10"></i>
                                                                Search
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>}

                                        <div className="D">
                                            {activeTab === 2 && <div class="d">
                                                <div class="tabs__pane -tab-item-1 is-tab-el-active">
                                                    <div class="mainSearch bg-white pr-20 py-20 lg:px-20 lg:pt-5 lg:pb-20 rounded-4 shadow-1">
                                                        <div class="button-grid items-center grid-colams">

                                                            <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch -is-dd-wrap-active">

                                                                <div data-x-dd-click="searchMenu-loc">
                                                                    <h4 class="text-15 fw-500 ls-2 lh-16">Location</h4>

                                                                    <div class="text-15 text-light-1 ls-2 lh-16">
                                                                        <input autocomplete="off" type="search"
                                                                            // value={cityvalD}
                                                                            // onChange={(e) => { handleChangeCity(e.target.value) }}
                                                                            placeholder="Where are you going?" class="js-search js-dd-focus" />
                                                                    </div>
                                                                </div>

                                                                <div class="searchMenu-loc__field shadow-2 js-popup-window -is-active" data-x-dd="searchMenu-loc" data-x-dd-toggle="-is-active">
                                                                    <div class="bg-white px-30 py-30 sm:px-0 sm:py-15 rounded-4">
                                                                        <div class="y-gap-5 js-results">

                                                                            <div className="cityDataScroll">
                                                                                {
                                                                                    cityFilterValue?.map((data) => {
                                                                                        return (
                                                                                            <button key={data.cityName} class="-link d-block col-12 text-left rounded-4 px-20 py-15 js-search-option" onClick={(e) => { e.stopPropagation(); handleCitySelect(data); }} >
                                                                                                <div class="d-flex">
                                                                                                    <div class="icon-location-2 text-light-1 text-20 pt-4"></div>
                                                                                                    <div class="ml-10">
                                                                                                        <div class="text-15 lh-12 fw-500 js-search-option-target">{data.cityName}</div>
                                                                                                        <div class="text-14 lh-12 text-light-1 mt-5">{data.countryName}
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </button>
                                                                                        )
                                                                                    })
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch">

                                                                <div data-x-dd-click="searchMenu-loc">
                                                                    <h4 class="text-15 fw-500 ls-2 lh-16">Destination</h4>

                                                                    <div class="text-15 text-light-1 ls-2 lh-16">
                                                                        <input autocomplete="off"
                                                                            // value={cityvalueD}
                                                                            // onChange={(e) => { handleChangeCityDest(e.target.value) }}
                                                                            type="search" placeholder="Where are you going?" class="js-search js-dd-focus" />
                                                                    </div>

                                                                </div>

                                                                <div class="searchMenu-loc__field shadow-2 js-popup-window -is-active" data-x-dd="searchMenu-loc" data-x-dd-toggle="-is-active">
                                                                    <div class="bg-white px-30 py-30 sm:px-0 sm:py-15 rounded-4">
                                                                        <div class="y-gap-5 js-results">

                                                                            <div className="cityDataScroll">
                                                                                {
                                                                                    cityFilterValueDest?.map((data) => {
                                                                                        return (
                                                                                            <button key={data.cityName} class="-link d-block col-12 text-left rounded-4 px-20 py-15 js-search-option">
                                                                                                <div class="d-flex" onClick={(e) => { e.stopPropagation(); handleCitySelect(data); }}>
                                                                                                    <div class="icon-location-2 text-light-1 text-20 pt-4"></div>
                                                                                                    <div class="ml-10">
                                                                                                        <div class="text-15 lh-12 fw-500 js-search-option-target">{data.cityName}</div>
                                                                                                        <div class="text-14 lh-12 text-light-1 mt-5">{data.countryName}
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </button>
                                                                                        )
                                                                                    })
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="searchMenu-date px-10 lg:py-20 lg:px-0 js-form-dd js-calendar">
                                                                <div data-x-dd-click="searchMenu-date">
                                                                    <h4 class="text-15 fw-500 ls-2 lh-16">Check in - Check out</h4>

                                                                </div>
                                                            </div>
                                                            <div class="searchMenu-guests px-30 lg:py-20 lg:px-0 js-form-dd js-form-counters">

                                                                <div data-x-dd-click="searchMenu-guests">
                                                                    <h4 class="text-15 fw-500 ls-2 lh-16">Guest</h4>

                                                                    <div class="text-15 text-light-1 ls-2 lh-16">
                                                                        <select className="form-control">
                                                                            <option>Adults</option>
                                                                            <option>Childeren</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="button-item">
                                                                <button class="mainSearch__submit button -dark-1 py-15 px-35 h-60 col-12 rounded-4 bg-blue-1 text-white">
                                                                    <i class="icon-search text-20 mr-10"></i>
                                                                    Search
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>}



                                            {activeTab === 3 &&
                                                <div class="tabs__pane -tab-item-1 is-tab-el-active">
                                                    <div class="mainSearch bg-white pr-20 py-20 lg:px-20 lg:pt-5 lg:pb-20 rounded-4 shadow-1">
                                                        <div class="button-grid items-center grid-colams hotelscols">

                                                            <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch -is-dd-wrap-active">

                                                                <div data-x-dd-click="searchMenu-loc">
                                                                    <h4 class="text-15 fw-500 ls-2 lh-16">Location</h4>

                                                                    <div class="text-15 text-light-1 ls-2 lh-16">
                                                                        <input autocomplete="off" type="text"
                                                                            value={cityvalue}
                                                                            onChange={(e) => { handleChangeCity(e.target.value) }}
                                                                            placeholder="Where are you going?" class="js-search js-dd-focus"
                                                                        />



                                                                    </div>

                                                                    {cityFilterValue && cityFilterValue.length > 0 && (
                                                                        <div class="searchMenu-loc__field shadow-2 js-popup-window -is-active" data-x-dd="searchMenu-loc" data-x-dd-toggle="-is-active">
                                                                            <div class="bg-white px-30 py-30 sm:px-0 sm:py-15 rounded-4">
                                                                                <div class="y-gap-5 js-results">

                                                                                    <div className="cityDataScroll">
                                                                                        {
                                                                                            cityFilterValue?.map((data) => {
                                                                                                return (
                                                                                                    <button key={data.cityName} class="-link d-block col-12 text-left rounded-4 px-20 py-15 js-search-option">
                                                                                                        <div class="d-flex" onClick={(e) => { e.stopPropagation(); handleCitySelect(data); setCityFilterValue(null); }}>
                                                                                                            <div class="icon-location-2 text-light-1 text-20 pt-4"></div>
                                                                                                            <div class="ml-10">
                                                                                                                <div class="text-15 lh-12 fw-500 js-search-option-target">{data.cityName}</div>
                                                                                                                <div class="text-14 lh-12 text-light-1 mt-5">{data.countryName}
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </button>
                                                                                                )
                                                                                            })
                                                                                        }
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>)}
                                                                </div>
                                                            </div>


                                                            <div class="searchMenu-date px-30 lg:py-20 lg:px-0 js-form-dd js-calendar">

                                                                <div data-x-dd-click="searchMenu-date">
                                                                    <h4 class="text-15 fw-500 ls-2 lh-16">Check in - Check out</h4>
                                                                    <div>
                                                                        <Datepicker classNames="date_width" value={{ startDate: selectedDates.startDate, endDate: selectedDates.endDate }} onChange={handleValueChangedate} />
                                                                    </div>



                                                                </div>
                                                            </div>

                                                            <div class="searchMenu-guests px-30 lg:py-20 lg:px-0 js-form-dd js-form-counters">

                                                                <div data-x-dd-click="searchMenu-guests">
                                                                    <h4 class="text-15 fw-500 ls-2 lh-16" >Guest</h4>


                                                                    <div class="text-15 text-light-1 ls-2 lh-16" onClick={handleshow}>
                                                                        <span class="js-count-adult">{adults}</span> adults {" "}
                                                                        <span class="js-count-child">{children}</span> children {" "}
                                                                        <span class="js-count-room">{rooms}</span> rooms
                                                                    </div>

                                                                </div>
                                                                {isShown ?




                                                                    <div class="searchMenu-guests__field shadow-2 -is-active" data-x-dd="searchMenu-guests" data-x-dd-toggle="-is-active">
                                                                        <div class="bg-white px-30 py-30 rounded-4">
                                                                            <div class="row y-gap-10 justify-between items-center">
                                                                                <div class="col-auto">
                                                                                    <div class="text-15 fw-500">Adults</div>
                                                                                </div>

                                                                                <div class="col-auto">
                                                                                    <div class="d-flex items-center js-counter" data-value-change=".js-count-adult">
                                                                                        <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleAdultsDecrement}>
                                                                                            <i class="icon-minus text-12"></i>
                                                                                        </button>

                                                                                        <div class="flex-center size-20 ml-15 mr-15">
                                                                                            <div class="text-15 js-count">{adults}</div>
                                                                                        </div>

                                                                                        <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleAdultsIncrement}>
                                                                                            <i class="icon-plus text-12"></i>
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="border-top-light mt-24 mb-24"></div>

                                                                            <div class="row y-gap-10 justify-between items-center">
                                                                                <div class="col-auto">
                                                                                    <div class="text-15 lh-12 fw-500">Children</div>

                                                                                </div>

                                                                                <div class="col-auto">
                                                                                    <div class="d-flex items-center js-counter" data-value-change=".js-count-child">
                                                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleChildrenDecrement}>
                                                                                            <i class="icon-minus text-12"></i>
                                                                                        </button>

                                                                                        <div class="flex-center size-20 ml-15 mr-15">
                                                                                            <div class="text-15 js-count">{children}</div>
                                                                                        </div>

                                                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleChildrenIncrement}>
                                                                                            <i class="icon-plus text-12"></i>
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="border-top-light mt-24 mb-24"></div>

                                                                            <div class="row y-gap-10 justify-between items-center">
                                                                                <div class="col-auto">
                                                                                    <div class="text-15 fw-500">Rooms</div>
                                                                                </div>

                                                                                <div class="col-auto">
                                                                                    <div class="d-flex items-center js-counter" data-value-change=".js-count-room">
                                                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleRoomsDecrement}>
                                                                                            <i class="icon-minus text-12"></i>
                                                                                        </button>

                                                                                        <div class="flex-center size-20 ml-15 mr-15">
                                                                                            <div class="text-15 js-count">{rooms}</div>
                                                                                        </div>

                                                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleRoomsIncrement}>
                                                                                            <i class="icon-plus text-12"></i>
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div> : null
                                                                }

                                                            </div>

                                                            <div class="button-item">
                                                                <button class="mainSearch__submit button -dark-1 py-15 px-35 h-60 col-12 rounded-4 bg-blue-1 text-white" onClick={() => {
                                                                    Searchlist()

                                                                }}
                                                                >
                                                                    <i class="icon-search text-20 mr-10"></i>
                                                                    Search
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="moreOption text-white">
                                                        <div className="selextbox">

                                                            <DropdownButton id="dropdown-basic-button" className="bg-arrowndown dropdown-basic-button2" title="Rating">
                                                                <i class="fa fa-angle-down" aria-hidden="true"></i>
                                                                <div className="form-check">
                                                                    <input className="form-check-input" type="checkbox" value="5" id="onestar5" onChange={handleRatingChange} />
                                                                    <label className="form-check-label" htmlFor="onestar5">
                                                                        5 Star
                                                                    </label>
                                                                </div>
                                                                <div className="form-check">
                                                                    <input className="form-check-input" type="checkbox" value="4" id="onestar4" onChange={handleRatingChange} />
                                                                    <label className="form-check-label" htmlFor="onestar4">
                                                                        4 Star
                                                                    </label>
                                                                </div>
                                                                <div className="form-check">
                                                                    <input className="form-check-input" type="checkbox" value="3" id="onestar3" onChange={handleRatingChange} />
                                                                    <label className="form-check-label" htmlFor="onestar3">
                                                                        3 Star
                                                                    </label>
                                                                </div>
                                                                <div className="form-check">
                                                                    <input className="form-check-input" type="checkbox" value="2" id="onestar2" onChange={handleRatingChange} />
                                                                    <label className="form-check-label" htmlFor="onestar2">
                                                                        2 Star
                                                                    </label>
                                                                </div>
                                                                <div className="form-check">
                                                                    <input className="form-check-input" type="checkbox" value="1" id="onestar" onChange={handleRatingChange} />
                                                                    <label className="form-check-label" htmlFor="onestar">
                                                                        1 Star
                                                                    </label>
                                                                </div>
                                                            </DropdownButton>
                                                        </div>
                                                        <div className="selextbox">

                                                            <select className="bg-arrowndown dropdown-basic-button2" onChange={handleCountryChange}>
                                                                <option>Netionality</option>
                                                                {Country.map((country, index) => (
                                                                    <option key={index}>{country.name}</option>
                                                                ))}
                                                            </select>
                                                        </div>
                                                        <div className="selextbox">

                                                            <select className="bg-arrowndown dropdown-basic-button2" onChange={handleChangeNationlity}>
                                                                <option>Country</option>
                                                                {Country.map((country, index) => (
                                                                    <option key={index}>{country.name}</option>
                                                                ))}
                                                            </select>
                                                        </div>
                                                        <div className="selextbox selectcheck">
                                                            <div className="form-check">
                                                                <input className="form-check-input" type="checkbox" defaultValue id="onestar" />
                                                                <label className="form-check-label" htmlFor="onestar">
                                                                    Special Category
                                                                </label>

                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>}

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                {/* <section className="layout-pt-lg layout-pb-md">
                    <div className="container animated">
                        <div data-anim-child="slide-up delay-1" className="row justify-center text-center is-in-view">
                            <div className="col-auto">
                                <div className="sectionTitle -md">
                                    <h2 className="sectionTitle__title">Special Offers</h2>
                                    <p className=" sectionTitle__text mt-5 sm:mt-0">These popular destinations have a lot to offer</p>
                                </div>
                            </div>
                        </div>
                        <div className="row y-gap-20 pt-40">
                            <div data-anim-child="slide-left delay-3" className="col-lg-4 col-sm-6 is-in-view">
                                <div className="ctaCard -type-1 rounded-4 ">
                                    <div className="ctaCard__image ratio ratio-41:45">
                                        <img className="img-ratio js-lazy error" src={offer1} alt="image" />
                                    </div>
                                    <div className="ctaCard__content py-50 px-50 lg:py-30 lg:px-30">
                                        <h4 className="text-30 lg:text-24 text-white">Things To Do On<br /> Your Trip</h4>
                                        <div className="d-inline-block mt-30">
                                            <a href="#" className="button px-48 py-15 -blue-1 -min-180 bg-white text-dark-1">Experiences</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div data-anim-child="slide-left delay-4" className="col-lg-4 col-sm-6 is-in-view">
                                <div className="ctaCard -type-1 rounded-4 ">
                                    <div className="ctaCard__image ratio ratio-41:45">
                                        <img className="img-ratio js-lazy error" src={offer2} alt="image" />
                                    </div>
                                    <div className="ctaCard__content py-50 px-50 lg:py-30 lg:px-30">
                                        <h4 className="text-30 lg:text-24 text-white">Let Your Curiosity<br />Do The Booking</h4>
                                        <div className="d-inline-block mt-30">
                                            <a href="#" className="button px-48 py-15 -blue-1 -min-180 bg-white text-dark-1">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div data-anim-child="slide-left delay-5" className="col-lg-4 col-sm-6 is-in-view">
                                <div className="ctaCard -type-1 rounded-4 ">
                                    <div className="ctaCard__image ratio ratio-41:45">
                                        <img className="img-ratio js-lazy error" src={offer3} alt="image" />
                                    </div>
                                    <div className="ctaCard__content py-50 px-50 lg:py-30 lg:px-30">
                                        <div className="text-15 fw-500 text-white mb-10">Enjoy Summer Deals</div>
                                        <h4 className="text-30 lg:text-24 text-white">Up to 70% Discount!</h4>
                                        <div className="d-inline-block mt-30">
                                            <a href="#" className="button px-48 py-15 -blue-1 -min-180 bg-white text-dark-1">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> */}
                {/* <section className="layout-pt-md layout-pb-md">
                    <div className="container">
                        <div className="row justify-center text-center">
                            <div className="col-auto">
                                <div className="sectionTitle -md">
                                    <h2 className="sectionTitle__title">Why Choose Us</h2>
                                    <p className=" sectionTitle__text mt-5 sm:mt-0">These popular destinations have a lot to offer</p>
                                </div>
                            </div>
                        </div>
                        <div className="row y-gap-40 justify-between pt-50">
                            <div className="col-lg-3 col-sm-6">
                                <div className="featureIcon -type-1 ">
                                    <div className="d-flex justify-center">
                                        <img src={featurelicon1} alt="image" className="js-lazy loaded" data-ll-status="loaded" />
                                    </div>
                                    <div className="text-center mt-30">
                                        <h4 className="text-18 fw-500">Best Price Guarantee</h4>
                                        <p className="text-15 mt-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3 col-sm-6">
                                <div className="featureIcon -type-1 ">
                                    <div className="d-flex justify-center">
                                        <img src={featurelicon2} alt="image" className="js-lazy loaded" data-ll-status="loaded" />
                                    </div>
                                    <div className="text-center mt-30">
                                        <h4 className="text-18 fw-500">Easy &amp; Quick Booking</h4>
                                        <p className="text-15 mt-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3 col-sm-6">
                                <div className="featureIcon -type-1 ">
                                    <div className="d-flex justify-center">
                                        <img src={featurelicon3} alt="image" className="js-lazy loaded" data-ll-status="loaded" />
                                    </div>
                                    <div className="text-center mt-30">
                                        <h4 className="text-18 fw-500">Customer Care 24/7</h4>
                                        <p className="text-15 mt-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> */}
                {/* <section className="layout-pt-md layout-pb-md">
                    <div className="container">
                        <div className="row justify-center text-center">
                            <div className="col-auto">
                                <div className="sectionTitle -md">
                                    <h2 className="sectionTitle__title">Top Destinations</h2>
                                    <p className=" sectionTitle__text mt-5 sm:mt-0">These popular destinations have a lot to offer</p>
                                </div>
                            </div>
                        </div>
                        <div className="row y-gap-40 justify-between pt-40 sm:pt-20">
                            <div className="col-xl-3 col-md-4 col-sm-6">
                                <a href="#" className="citiesCard -type-3 d-block rounded-4 ">
                                    <div className="citiesCard__image ratio ratio-1:1">
                                        <img className="img-ratio js-lazy" src={topdestinations} alt="image" />
                                    </div>
                                    <div className="citiesCard__content px-30 py-30">
                                        <h4 className="text-26 fw-600 text-white">Los Angeles</h4>
                                        <div className="text-15 text-white">1,714 properties</div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-6 col-md-4 col-sm-6">
                                <a href="#" className="citiesCard -type-3 d-block rounded-4 h-full">
                                    <div className="citiesCard__image ">
                                        <img className="img-ratio js-lazy" src={topdestinations2} alt="image" />
                                    </div>
                                    <div className="citiesCard__content px-30 py-30">
                                        <h4 className="text-26 fw-600 text-white">London</h4>
                                        <div className="text-15 text-white">1,714 properties</div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-md-4 col-sm-6">
                                <a href="#" className="citiesCard -type-3 d-block rounded-4 ">
                                    <div className="citiesCard__image ratio ratio-1:1">
                                        <img className="img-ratio js-lazy" src={topdestinations3} alt="image" />
                                    </div>
                                    <div className="citiesCard__content px-30 py-30">
                                        <h4 className="text-26 fw-600 text-white">Reykjavik</h4>
                                        <div className="text-15 text-white">1,714 properties</div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-6 col-md-4 col-sm-6">
                                <a href="#" className="citiesCard -type-3 d-block rounded-4 h-full">
                                    <div className="citiesCard__image ">
                                        <img className="img-ratio js-lazy" src={topdestinations4} alt="image" />
                                    </div>
                                    <div className="citiesCard__content px-30 py-30">
                                        <h4 className="text-26 fw-600 text-white">Paris</h4>
                                        <div className="text-15 text-white">1,714 properties</div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-md-4 col-sm-6">
                                <a href="#" className="citiesCard -type-3 d-block rounded-4 ">
                                    <div className="citiesCard__image ratio ratio-1:1">
                                        <img className="img-ratio js-lazy" src={topdestinations5} alt="image" />
                                    </div>
                                    <div className="citiesCard__content px-30 py-30">
                                        <h4 className="text-26 fw-600 text-white">Amsterdam</h4>
                                        <div className="text-15 text-white">1,714 properties</div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-md-4 col-sm-6">
                                <a href="#" className="citiesCard -type-3 d-block rounded-4 ">
                                    <div className="citiesCard__image ratio ratio-1:1">
                                        <img className="img-ratio js-lazy" src={topdestinations6} alt="image" />
                                    </div>
                                    <div className="citiesCard__content px-30 py-30">
                                        <h4 className="text-26 fw-600 text-white">Istanbul</h4>
                                        <div className="text-15 text-white">1,714 properties</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </section> */}

                {/* <section className="layout-pt-md layout-pb-md">
                    <div className="container">
                        <div className="row y-gap-20 justify-between items-end">
                            <div className="col-auto">
                                <div className="sectionTitle -md">
                                    <h2 className="sectionTitle__title">Recommended Hotels</h2>
                                    <p className=" sectionTitle__text mt-5 sm:mt-0">Interdum et malesuada fames ac ante ipsum</p>
                                </div>
                            </div>
                            <div className="col-auto">
                                <a href="#" className="button -md -blue-1 bg-blue-1-05 text-blue-1">
                                    More <div className="icon-arrow-top-right ml-15" />
                                </a>
                            </div>
                        </div>
                        <div className="row y-gap-30 pt-40 sm:pt-20">
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="hotel-single-1.html" className="hotelsCard -type-1 ">
                                    <div className="hotelsCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={recommendedhotel} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                            <div className="cardImage__leftBadge">
                                                <div className="py-5 px-15 rounded-right-4 text-12 lh-16 fw-500 uppercase bg-dark-1 text-white">
                                                    Breakfast included
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="hotelsCard__content mt-10">
                                        <h4 className="hotelsCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>The Montcalm At Brewery London City</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Westminster Borough, London</p>
                                        <div className="d-flex items-center mt-20">
                                            <div className="flex-center bg-blue-1 rounded-4 size-30 text-12 fw-600 text-white">4.8</div>
                                            <div className="text-14 text-dark-1 fw-500 ml-10">Exceptional</div>
                                            <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                        </div>
                                        <div className="mt-5">
                                            <div className="fw-500">
                                                Starting from <span className="text-blue-1">US$72</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="hotel-single-1.html" className="hotelsCard -type-1 ">
                                    <div className="hotelsCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={recommendedhotel2} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="hotelsCard__content mt-10">
                                        <h4 className="hotelsCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>Staycity Aparthotels Deptford Bridge Station</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Ciutat Vella, Barcelona</p>
                                        <div className="d-flex items-center mt-20">
                                            <div className="flex-center bg-blue-1 rounded-4 size-30 text-12 fw-600 text-white">4.8</div>
                                            <div className="text-14 text-dark-1 fw-500 ml-10">Exceptional</div>
                                            <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                        </div>
                                        <div className="mt-5">
                                            <div className="fw-500">
                                                Starting from <span className="text-blue-1">US$72</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="hotel-single-1.html" className="hotelsCard -type-1 ">
                                    <div className="hotelsCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={recommendedhotel3} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                            <div className="cardImage__leftBadge">
                                                <div className="py-5 px-15 rounded-right-4 text-12 lh-16 fw-500 uppercase bg-blue-1 text-white">
                                                    Best Seller
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="hotelsCard__content mt-10">
                                        <h4 className="hotelsCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>The Westin New York at Times Square</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Manhattan, New York</p>
                                        <div className="d-flex items-center mt-20">
                                            <div className="flex-center bg-blue-1 rounded-4 size-30 text-12 fw-600 text-white">4.8</div>
                                            <div className="text-14 text-dark-1 fw-500 ml-10">Exceptional</div>
                                            <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                        </div>
                                        <div className="mt-5">
                                            <div className="fw-500">
                                                Starting from <span className="text-blue-1">US$72</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="hotel-single-1.html" className="hotelsCard -type-1 ">
                                    <div className="hotelsCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={recommendedhotel4} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                            <div className="cardImage__leftBadge">
                                                <div className="py-5 px-15 rounded-right-4 text-12 lh-16 fw-500 uppercase bg-yellow-1 text-dark-1">
                                                    Top Rated
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="hotelsCard__content mt-10">
                                        <h4 className="hotelsCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>DoubleTree by Hilton Hotel New York Times Square West</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Vaticano Prati, Rome</p>
                                        <div className="d-flex items-center mt-20">
                                            <div className="flex-center bg-blue-1 rounded-4 size-30 text-12 fw-600 text-white">4.8</div>
                                            <div className="text-14 text-dark-1 fw-500 ml-10">Exceptional</div>
                                            <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                        </div>
                                        <div className="mt-5">
                                            <div className="fw-500">
                                                Starting from <span className="text-blue-1">US$72</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </section> */}

                {/* <section className="layout-pt-md layout-pb-md">
                    <div className="container">
                        <div className="row y-gap-20 justify-between items-end">
                            <div className="col-auto">
                                <div className="sectionTitle -md">
                                    <h2 className="sectionTitle__title">Most Popular Tours</h2>
                                    <p className=" sectionTitle__text mt-5 sm:mt-0">Interdum et malesuada fames ac ante ipsum</p>
                                </div>
                            </div>
                            <div className="col-auto">
                                <a href="#" className="button -md -blue-1 bg-blue-1-05 text-blue-1">
                                    More <div className="icon-arrow-top-right ml-15" />
                                </a>
                            </div>
                        </div>
                        <div className="row y-gap-30 pt-40 sm:pt-20">
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="#" className="tourCard -type-1 rounded-4 ">
                                    <div className="tourCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={tours} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                            <div className="cardImage__leftBadge">
                                                <div className="py-5 px-15 rounded-right-4 text-12 lh-16 fw-500 uppercase bg-dark-1 text-white">
                                                    LIKELY TO SELL OUT*
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="tourCard__content mt-10">
                                        <div className="d-flex items-center lh-14 mb-5">
                                            <div className="text-14 text-light-1">16+ hours</div>
                                            <div className="size-3 bg-light-1 rounded-full ml-10 mr-10" />
                                            <div className="text-14 text-light-1">Full-day Tours</div>
                                        </div>
                                        <h4 className="tourCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>Stonehenge, Windsor Castle and Bath with Pub Lunch in Lacock</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Westminster Borough, London</p>
                                        <div className="row justify-between items-center pt-15">
                                            <div className="col-auto">
                                                <div className="d-flex items-center">
                                                    <div className="d-flex items-center x-gap-5">
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                    </div>
                                                    <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                                </div>
                                            </div>
                                            <div className="col-auto">
                                                <div className="text-14 text-light-1">
                                                    From
                                                    <span className="text-16 fw-500 text-dark-1">US$72</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="#" className="tourCard -type-1 rounded-4 ">
                                    <div className="tourCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={tours2} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="tourCard__content mt-10">
                                        <div className="d-flex items-center lh-14 mb-5">
                                            <div className="text-14 text-light-1">9+ hours</div>
                                            <div className="size-3 bg-light-1 rounded-full ml-10 mr-10" />
                                            <div className="text-14 text-light-1">Attractions &amp; Museums</div>
                                        </div>
                                        <h4 className="tourCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>Westminster Walking Tour &amp; Westminster Abbey Entry</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Ciutat Vella, Barcelona</p>
                                        <div className="row justify-between items-center pt-15">
                                            <div className="col-auto">
                                                <div className="d-flex items-center">
                                                    <div className="d-flex items-center x-gap-5">
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                    </div>
                                                    <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                                </div>
                                            </div>
                                            <div className="col-auto">
                                                <div className="text-14 text-light-1">
                                                    From
                                                    <span className="text-16 fw-500 text-dark-1">US$72</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="#" className="tourCard -type-1 rounded-4 ">
                                    <div className="tourCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={tours3} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                            <div className="cardImage__leftBadge">
                                                <div className="py-5 px-15 rounded-right-4 text-12 lh-16 fw-500 uppercase bg-blue-1 text-white">
                                                    Best Seller
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="tourCard__content mt-10">
                                        <div className="d-flex items-center lh-14 mb-5">
                                            <div className="text-14 text-light-1">40–55 minutes</div>
                                            <div className="size-3 bg-light-1 rounded-full ml-10 mr-10" />
                                            <div className="text-14 text-light-1">Private and Luxury</div>
                                        </div>
                                        <h4 className="tourCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>High-Speed Thames River RIB Cruise in London</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Manhattan, New York</p>
                                        <div className="row justify-between items-center pt-15">
                                            <div className="col-auto">
                                                <div className="d-flex items-center">
                                                    <div className="d-flex items-center x-gap-5">
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                    </div>
                                                    <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                                </div>
                                            </div>
                                            <div className="col-auto">
                                                <div className="text-14 text-light-1">
                                                    From
                                                    <span className="text-16 fw-500 text-dark-1">US$72</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div className="col-xl-3 col-lg-3 col-sm-6">
                                <a href="#" className="tourCard -type-1 rounded-4 ">
                                    <div className="tourCard__image">
                                        <div className="cardImage ratio ratio-1:1">
                                            <div className="cardImage__content">
                                                <img className="rounded-4 col-12" src={tours4} alt="image" />
                                            </div>
                                            <div className="cardImage__wishlist">
                                                <button className="button -blue-1 bg-white size-30 rounded-full shadow-2">
                                                    <i className="icon-heart text-12" />
                                                </button>
                                            </div>
                                            <div className="cardImage__leftBadge">
                                                <div className="py-5 px-15 rounded-right-4 text-12 lh-16 fw-500 uppercase bg-yellow-1 text-dark-1">
                                                    Top Rated
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="tourCard__content mt-10">
                                        <div className="d-flex items-center lh-14 mb-5">
                                            <div className="text-14 text-light-1">94+ days</div>
                                            <div className="size-3 bg-light-1 rounded-full ml-10 mr-10" />
                                            <div className="text-14 text-light-1">Bus Tours</div>
                                        </div>
                                        <h4 className="tourCard__title text-dark-1 text-18 lh-16 fw-500">
                                            <span>Edinburgh Darkside Walking Tour: Mysteries, Murder and Legends</span>
                                        </h4>
                                        <p className="text-light-1 lh-14 text-14 mt-5">Vaticano Prati, Rome</p>
                                        <div className="row justify-between items-center pt-15">
                                            <div className="col-auto">
                                                <div className="d-flex items-center">
                                                    <div className="d-flex items-center x-gap-5">
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                        <div className="icon-star text-yellow-1 text-10" />
                                                    </div>
                                                    <div className="text-14 text-light-1 ml-10">3,014 reviews</div>
                                                </div>
                                            </div>
                                            <div className="col-auto">
                                                <div className="text-14 text-light-1">
                                                    From
                                                    <span className="text-16 fw-500 text-dark-1">US$72</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </section> */}


            </main>
        </div>



    )
}
export default Tabss;


























