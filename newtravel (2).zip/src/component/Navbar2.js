import React from "react";
import { Link } from "react-router-dom";

const Navbar2 = () =>{
    return(
        <nav className="parent1">

       <ul className="navlist">
         <li><Link to="/Login">Login</Link></li>
         <li><Link to="/Register">Register</Link></li>

        

       </ul>
     </nav>
    )
}
export default Navbar2;