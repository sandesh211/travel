import React, { useState } from "react";
import Datepicker from "react-tailwindcss-datepicker";
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import homebanner from "../../src/images/flight-bg.png"
import Header from "./Header";
import Footer from "./Footer";

const Flight = () => {
  const [isShown, setIsShown] = useState(false);
  const [adults, setAdults] = useState(0);
  const [children, setChildren] = useState(0);
  const [rooms, setRooms] = useState(0);

  const handleshow = event => {

    if (isShown == false) {
      setIsShown(true)

    } else {
      setIsShown(false)
    }
  };

  const handleAdultsDecrement = () => {
    if (adults > 0) {
      setAdults(adults - 1);
    }
  };

  const handleAdultsIncrement = () => {
    setAdults(adults + 1);
  };

  const handleChildrenDecrement = () => {
    if (children > 0) {
      setChildren(children - 1);
    }
  };

  const handleChildrenIncrement = () => {
    setChildren(children + 1);
  };

  const handleRoomsDecrement = () => {
    if (rooms > 0) {
      setRooms(rooms - 1);
    }
  };

  const handleRoomsIncrement = () => {
    setRooms(rooms + 1);
  };

  const tabs = [
    { title: 'Tab 1', content: 'This is the content for Tab 1' },
    { title: 'Tab 2', content: 'This is the content for Tab 2' },
    { title: 'Tab 3', content: 'This is the content for Tab 3' },
  ];



  const [value, setValue] = useState({
    startDate: new Date(),
    endDate: new Date().setMonth(11)
  });

  const handleValueChange = (newValue) => {
    console.log("newValue:", newValue);
    setValue(newValue);
  }
  return (
    <div>

      <main>
        <section className="masthead -type-3 flight-space relative z-5" style={{ backgroundImage: `url(${homebanner})` }}>
          <div className="container">
            <div className="text-center">
              <h1 className="text-60 lg:text-40 md:text-30 text-white">Find Your Flight</h1>

            </div>
            <div class="tabs__pane -tab-item-1 is-tab-el-active">
              <div class="mainSearch bg-transparent bg-white pr-20 py-20 lg:px-20 lg:pt-5 lg:pb-20 rounded-4 shadow-1">
                <div className="toggle_radio onewaycity">

                  <input type="radio" className="toggle_option" id="first_toggle" name="toggle_option" />
                  <input type="radio" defaultChecked className="toggle_option" id="second_toggle" name="toggle_option" />
                  <input type="radio" className="toggle_option" id="third_toggle" name="toggle_option" />
                  <label htmlFor="first_toggle"><p>ONE WAY</p></label>
                  <label htmlFor="second_toggle"><p>ROUND TRIP</p></label>
                  <label htmlFor="third_toggle"><p>MULTI CITY</p></label>
                  <div className="toggle_option_slider">
                  </div>
                </div>

                <div class="button-grid items-center grid-colams">
                  <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch -is-dd-wrap-active">
                    <div data-x-dd-click="searchMenu-loc">
                      <h4 class="text-15 fw-500 ls-2 lh-16">Location</h4>
                      <div class="text-15 text-light-1 ls-2 lh-16">
                        <input autocomplete="off" type="search" placeholder="Where are you going?" class="js-search js-dd-focus" />
                      </div>
                    </div>
                  </div>
                  <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch">
                    <div data-x-dd-click="searchMenu-loc">
                      <h4 class="text-15 fw-500 ls-2 lh-16">Location</h4>

                      <div class="text-15 text-light-1 ls-2 lh-16">
                        <input autocomplete="off" type="search" placeholder="Where are you going?" class="js-search js-dd-focus" />
                      </div>
                    </div>
                  </div>
                  <div class="searchMenu-date px-10 lg:py-20 lg:px-0 js-form-dd js-calendar">
                    <div data-x-dd-click="searchMenu-date">
                      <h4 class="text-15 fw-500 ls-2 lh-16">Check in - Check out</h4>
                      <div>
                        <Datepicker classNames="date_width"
                          value={value}
                          onChange={handleValueChange}
                        />
                      </div>
                    </div>
                  </div>
                  <div class="searchMenu-guests px-30 lg:py-20 lg:px-0 js-form-dd js-form-counters">

                    <div data-x-dd-click="searchMenu-guests">
                      <h4 class="text-15 fw-500 ls-2 lh-16" >Guest</h4>


                      <div class="text-15 text-light-1 ls-2 lh-16" onClick={handleshow}>
                        <span class="js-count-adult">{adults}</span> adults {" "}
                        <span class="js-count-child">{children}</span> children {" "}
                        <span class="js-count-room">{rooms}</span> rooms
                      </div>

                    </div>
                    {isShown ?




                      <div class="searchMenu-guests__field shadow-2 -is-active" data-x-dd="searchMenu-guests" data-x-dd-toggle="-is-active">
                        <div class="bg-white px-30 py-30 rounded-4">
                          <div class="row y-gap-10 justify-between items-center">
                            <div class="col-auto">
                              <div class="text-15 fw-500">Adults</div>
                            </div>

                            <div class="col-auto">
                              <div class="d-flex items-center js-counter" data-value-change=".js-count-adult">
                                <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleAdultsDecrement}>
                                  <i class="icon-minus text-12"></i>
                                </button>

                                <div class="flex-center size-20 ml-15 mr-15">
                                  <div class="text-15 js-count">{adults}</div>
                                </div>

                                <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleAdultsIncrement}>
                                  <i class="icon-plus text-12"></i>
                                </button>
                              </div>
                            </div>
                          </div>

                          <div class="border-top-light mt-24 mb-24"></div>

                          <div class="row y-gap-10 justify-between items-center">
                            <div class="col-auto">
                              <div class="text-15 lh-12 fw-500">Children</div>

                            </div>

                            <div class="col-auto">
                              <div class="d-flex items-center js-counter" data-value-change=".js-count-child">
                                <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleChildrenDecrement}>
                                  <i class="icon-minus text-12"></i>
                                </button>

                                <div class="flex-center size-20 ml-15 mr-15">
                                  <div class="text-15 js-count">{children}</div>
                                </div>

                                <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleChildrenIncrement}>
                                  <i class="icon-plus text-12"></i>
                                </button>
                              </div>
                            </div>
                          </div>

                          <div class="border-top-light mt-24 mb-24"></div>

                          <div class="row y-gap-10 justify-between items-center">
                            <div class="col-auto">
                              <div class="text-15 fw-500">Rooms</div>
                            </div>

                            <div class="col-auto">
                              <div class="d-flex items-center js-counter" data-value-change=".js-count-room">
                                <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleRoomsDecrement}>
                                  <i class="icon-minus text-12"></i>
                                </button>

                                <div class="flex-center size-20 ml-15 mr-15">
                                  <div class="text-15 js-count">{rooms}</div>
                                </div>

                                <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleRoomsIncrement}>
                                  <i class="icon-plus text-12"></i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div> : null
                    }

                  </div>
                  <div class="button-item">
                    <button class="mainSearch__submit button -dark-1 py-15 px-35 h-60 col-12 rounded-4 bg-blue-1 text-white">
                      <i class="icon-search text-20 mr-10"></i>
                      Search
                    </button>
                  </div>
                </div>
              </div>
              <div className="moreOption text-white">
                <div className="selextbox">
                  <DropdownButton id="dropdown-basic-button" className="bg-arrowndown dropdown-basic-button2" title="Select Preferred Airline">
                    <i class="fa fa-angle-down" aria-hidden="true"></i>
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" defaultValue id="onestar5" />
                      <label className="form-check-label" htmlFor="onestar5">
                        Spicejet
                      </label>
                    </div>
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" defaultValue id="onestar4" />
                      <label className="form-check-label" htmlFor="onestar4">
                        Go First
                      </label>
                    </div>
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" defaultValue id="onestar3" />
                      <label className="form-check-label" htmlFor="onestar3">
                        Trujet
                      </label>
                    </div>
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" defaultValue id="onestar2" />
                      <label className="form-check-label" htmlFor="onestar2">
                        Vistara
                      </label>
                    </div>
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" defaultValue id="onestar" />
                      <label className="form-check-label" htmlFor="onestar">
                        Air India
                      </label>
                    </div>
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" defaultValue id="Indigo" />
                      <label className="form-check-label" htmlFor="Indigo">
                        Indigo
                      </label>
                    </div>
                  </DropdownButton>
                </div>

                <div className="selextbox selectcheck">
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" defaultValue id="Direct-Flight" />
                    <label className="form-check-label text-15 ml-5" For="Direct-Flight">
                      Direct Flight
                    </label>

                  </div>

                </div>
                <div className="selextbox selectcheck">
                  <div className="form-check">
                    <input className="form-check-input" type="checkbox" defaultValue id="Credit-Shell" />
                    <label className="form-check-label text-15 ml-5" For="Credit-Shell">
                      Credit Shell
                    </label>

                  </div>

                </div>


              </div>
              <div className="moreOption text-white">
                <div className="selextbox">
                  <h6 className="text-16 fw-400">Select Fare Type:</h6>
                </div>

                <div className="selextbox">

                  <div className="form-radio d-flex items-center ">
                    <div className="radio">
                      <input type="radio" name="name" id="regular-fares" />
                      <div className="radio__mark border-light">
                        <div className="radio__icon" />
                      </div>
                    </div>
                    <label className="ml-10" For="regular-fares">Regular Fares</label>
                  </div>
                </div>
                <div className="selextbox">
                  <div className="form-radio d-flex items-center ">
                    <div className="radio">
                      <input type="radio" name="name" id="Student-Fares" />
                      <div className="radio__mark border-light">
                        <div className="radio__icon" />
                      </div>
                    </div>
                    <label className="ml-10" For="Student-Fares">
                      Student Fares</label>
                  </div>
                </div>
                <div className="selextbox">
                  <div className="form-radio d-flex items-center ">
                    <div className="radio">
                      <input type="radio" name="name" id="seniar-citizen" />
                      <div className="radio__mark border-light">
                        <div className="radio__icon" />
                      </div>
                    </div>
                    <label className="ml-10" For="seniar-citizen">Senior Citizen Fares</label>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </section>
        <Footer />

      </main>

    </div>

  )
}
export default Flight;