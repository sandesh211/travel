import React from "react";

const Tour = () =>{
    return(
        <div>
<h1>This is Tour</h1>
        </div>
    )
}
export default Tour;