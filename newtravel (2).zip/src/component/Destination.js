import React from "react";

const Destination = () =>{
    return(
        <div>
<h1>This is destination</h1>
        </div>
    )
}
export default Destination;