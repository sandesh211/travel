import React,{useState,useEffect} from "react";
import Datepicker from "react-tailwindcss-datepicker";
import { useNavigate } from 'react-router-dom';
import DropdownButton from 'react-bootstrap/DropdownButton';
import homebannerhotel from "../../src/images/homebannerhote2.png"
import Country from './Country.json'
import axios from 'axios';
import Tabss from "./Tabss";
import Footer from "./Footer";

const Hotel = () => {
    const navigate = useNavigate();
    const [tripType, setTripType] = useState('oneWay');
    const [fareType, setFareType] = useState('');
    const [activeTab, setActiveTab] = useState(1);
    const [hotels, setHotels] = useState([]);
    const [allCities, setAllCities] = useState([]);
    const [filterCities, setFilterCities] = useState([]);
    const [searchQuery, setSearchQuery] = useState("");
    const [cityvalue, setCityValue] = useState("");
    const [cityval, setCityVal] = useState("");
    const [cityvalD, setCityValD] = useState("");
    const [cityvalus, setCityValus] = useState("");
    const [cityvalueD, setCityValueD] = useState("");
    const [cityFilterValue, setCityFilterValue] = useState([]);
    const [cityFilterValueDest, setCityFilterValueDest] = useState([]);
    const [searchList, setSearchList] = useState([]);
    const [selectedCountryId, setSelectedCountryId] = useState('');
    const [selectnationlity, setSelectnationlity] = useState('');
    const [selectedRatings, setSelectedRatings] = useState([]);
    const [selectedOption, setSelectedOption] = useState('Adult');
    const [isShown, setIsShown] = useState(false);
    const [isShowns, setIsShowns] = useState(false);
    const [isShownD, setIsShownD] = useState(false);
    const [isShownL, setIsShownL] = useState(false);
    const [isShownDe, setIsShownDe] = useState(false);
    const [isShownLo, setIsShownLo] = useState(false);

    const [adults, setAdults] = useState(0);
    const [children, setChildren] = useState(0);
    const [rooms, setRooms] = useState(0);
    const [setid, setSetid] = useState('');
    const [startDate, setStartDate] = useState('')
    const [endDate, setEndDate] = useState('')
    const [hotelResult, setHotelResult] = useState([])

    const [selectedDates, setSelectedDates] = useState({ startDate: null, endDate: null });

    const [selectedDate, setSelectedDate] = useState(null);


    

    const handleshow = event => {
       
        if (isShown == false) {
            setIsShown(true)

        } else {
            setIsShown(false)
        }
    };

    const handleshows = event => {
        if (isShowns == false) {
            setIsShowns(true)

        } else {
            setIsShowns(false)
        }
    };

    const handleshowD = event => {

        if (isShownD == false) {
            setIsShownD(true)

        } else {
            setIsShownD(false)
        }
    };


    const handleAdultsDecrement = () => {
        if (adults > 0) {
            setAdults(adults - 1);
        }
    };

    const handleAdultsIncrement = () => {
        setAdults(adults + 1);
    };

    const handleChildrenDecrement = () => {
        if (children > 0) {
            setChildren(children - 1);
        }
    };

    const handleChildrenIncrement = () => {
        setChildren(children + 1);
    };

    const handleRoomsDecrement = () => {
        if (rooms > 0) {
            setRooms(rooms - 1);
        }
    };

    const handleRoomsIncrement = () => {
        setRooms(rooms + 1);
    };

    const tabs = [
        { title: 'Tab 1', content: 'This is the content for Tab 1' },
        { title: 'Tab 2', content: 'This is the content for Tab 2' },
        { title: 'Tab 3', content: 'This is the content for Tab 3' },
    ];

    const handleValueChangedate = (value) => {
        if (value.startDate && value.endDate) {
            setSelectedDates({ startDate: value.startDate, endDate: value.endDate });
            setStartDate(value.startDate);
            setEndDate(value.endDate);

        }
    };
    const handleOptionChange = (event) => {
        setSelectedOption(event.target.value);

    };


    const handleRatingChange = (event) => {
        const rating = event.target.value;
        if (event.target.checked) {
            setSelectedRatings(prevRatings => [...prevRatings, rating]);
        } else {
            setSelectedRatings(prevRatings => prevRatings.filter(prevRating => prevRating !== rating));

        }
    }


    const handleCountryChange = (event) => {
        const selectedCountryName = event.target.value;
        const selectedCountry = Country.find(country => country.name === selectedCountryName);
        setSelectedCountryId(selectedCountry?.countryid);


    }
    const handleChangeNationlity = (event) => {
        const selectedCountryName = event.target.value;
        const selectedCountry = Country.find(country => country.name === selectedCountryName);
        setSelectnationlity(selectedCountry?.countryid);


    }
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setSearchQuery((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleTabClick = (tabIndex) => {
        setActiveTab(tabIndex);
    };

    const handleTripTypeChange = (event) => {
        setTripType(event.target.value);
    }

    const handleFareType = (event) => {
        setFareType(event.target.value);
    }
    const [value, setValue] = useState({
        startDate: new Date(),
        endDate: new Date().setMonth(11)

    });
    const Searchlist = () => {
        const apikey = "7121268d836907-c712-4301-81f3-bf819f0c159f";
        let config = {
            apikey: "7121268d836907-c712-4301-81f3-bf819f0c159f"
        }
        const searchQuery = {
            searchQuery: {
                checkinDate: startDate,
                checkoutDate: endDate,
                roomInfo: [
                    {
                        numberOfAdults: adults,
                        numberOfChild: children,
                        childAge: [6]
                    }
                ],
                searchCriteria: {
                    city:"740051",
                    // city: setid.toString(),
                    nationality: selectnationlity,
                    currency: "INR"
                },
                searchPreferences: {
                    ratings:
                        selectedRatings,
                    
                    fsc: true
                }
            },
            sync: true
        };
        const newConfig = {
            'Content-Type': 'application/json ',
            apikey: apikey

        }
        const data = JSON.stringify(searchQuery)
        axios.post("https://apitest.tripjack.com/hms/v1/hotel-searchquery-list", data, { headers: newConfig })
            .then((response) => {
                console.log("response", response);
                setHotelResult(response.data)
                navigate('/HotelList', { state: { data: response.data } });
            })
            .catch((error) => {
                console.log("error", error.message);
            });

    }

    function getAllCities() {
        const apikey = "7121268d836907-c712-4301-81f3-bf819f0c159f";
        let config = {
            apikey: "7121268d836907-c712-4301-81f3-bf819f0c159f"
        };
        axios.get("https://apitest.tripjack.com/hms/v1/static-cities/", {
            headers: config,
        }).then((res) => {

            setAllCities(res?.data?.response?.cil);
        }).catch((err) => { console.log("error", err); });
    }

    const handleChangeCity = (val) => {
        setCityValue(val)
  
        setCityValD(val)
        const newData = allCities.filter((data) => data.cityName.includes(val))
        setCityFilterValue(newData)
    }

    const handleChangeCityDest = (val) => {
        setCityValueD(val)
        const newData = allCities.filter((data) => data.cityName.includes(val))
        setCityFilterValueDest(newData)
    }
    const handleCitySelect = (val) => {
        setCityValue(val?.cityName);
        setSetid(val?.id)
        console.log("val", setid);
    };
    const handleCitySelectD = (val) => {
        const newData = allCities.filter((data) => data.cityName.includes(val))
        setCityFilterValueDest(newData?.cil?.id)
        console.log("newData", newData);
    };

    useEffect(() => {
        getAllCities();
    }, []);

    const subitLocation = (e, data) => {


        handleCitySelectD(data);
    }

    return (
        <div>
            <div class="header-margin"></div>
            <main>
                <section  className="masthead -type-3 flight-space relative z-5"style={{ backgroundImage: `url(${homebannerhotel})` }}>
                <div className="container">
                <div class="tabs__pane -tab-item-1 is-tab-el-active">
                    <div class="mainSearch bg-white pr-20 py-20 lg:px-20 lg:pt-5 lg:pb-20 rounded-4 shadow-1">
                        <div class="button-grid items-center grid-colams hotelscols">

                            <div class="searchMenu-loc px-30 lg:py-20 lg:px-0 js-form-dd js-liverSearch -is-dd-wrap-active">

                                <div data-x-dd-click="searchMenu-loc">
                                    <h4 class="text-15 fw-500 ls-2 lh-16">Location</h4>

                                    <div class="text-15 text-light-1 ls-2 lh-16">
                                        <input autocomplete="off" type="text"
                                            value={cityvalue}
                                            onChange={(e) => { handleChangeCity(e.target.value) }}
                                            placeholder="Where are you going?" class="js-search js-dd-focus"
                                        />



                                    </div>

                                    {cityFilterValue && cityFilterValue.length > 0 && (
                                        <div class="searchMenu-loc__field shadow-2 js-popup-window -is-active" data-x-dd="searchMenu-loc" data-x-dd-toggle="-is-active">
                                            <div class="bg-white px-30 py-30 sm:px-0 sm:py-15 rounded-4">
                                                <div class="y-gap-5 js-results">

                                                    <div className="cityDataScroll">
                                                        {
                                                            cityFilterValue?.map((data) => {
                                                                return (
                                                                    <button key={data.cityName} class="-link d-block col-12 text-left rounded-4 px-20 py-15 js-search-option">
                                                                        <div class="d-flex" onClick={(e) => { e.stopPropagation(); handleCitySelect(data); setCityFilterValue(null); }}>
                                                                            <div class="icon-location-2 text-light-1 text-20 pt-4"></div>
                                                                            <div class="ml-10">
                                                                                <div class="text-15 lh-12 fw-500 js-search-option-target">{data.cityName}</div>
                                                                                <div class="text-14 lh-12 text-light-1 mt-5">{data.countryName}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </button>
                                                                )
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                            </div>
                                        </div>)}
                                </div>
                            </div>


                            <div class="searchMenu-date px-30 lg:py-20 lg:px-0 js-form-dd js-calendar">

                                <div data-x-dd-click="searchMenu-date">
                                    <h4 class="text-15 fw-500 ls-2 lh-16">Check in - Check out</h4>
                                    <div>
                                        <Datepicker classNames="date_width" value={{ startDate: selectedDates.startDate, endDate: selectedDates.endDate }} onChange={handleValueChangedate} />
                                    </div>



                                </div>
                            </div>

                            <div class="searchMenu-guests px-30 lg:py-20 lg:px-0 js-form-dd js-form-counters">

                                <div data-x-dd-click="searchMenu-guests">
                                    <h4 class="text-15 fw-500 ls-2 lh-16" >Guest</h4>


                                    <div class="text-15 text-light-1 ls-2 lh-16" onClick={handleshow}>
                                        <span class="js-count-adult">{adults}</span> adults {" "}
                                        <span class="js-count-child">{children}</span> children {" "}
                                        <span class="js-count-room">{rooms}</span> rooms
                                    </div>

                                </div>
                                {isShown ?




                                    <div class="searchMenu-guests__field shadow-2 -is-active" data-x-dd="searchMenu-guests" data-x-dd-toggle="-is-active">
                                        <div class="bg-white px-30 py-30 rounded-4">
                                            <div class="row y-gap-10 justify-between items-center">
                                                <div class="col-auto">
                                                    <div class="text-15 fw-500">Adults</div>
                                                </div>

                                                <div class="col-auto">
                                                    <div class="d-flex items-center js-counter" data-value-change=".js-count-adult">
                                                        <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleAdultsDecrement}>
                                                            <i class="icon-minus text-12"></i>
                                                        </button>

                                                        <div class="flex-center size-20 ml-15 mr-15">
                                                            <div class="text-15 js-count">{adults}</div>
                                                        </div>

                                                        <button className="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleAdultsIncrement}>
                                                            <i class="icon-plus text-12"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="border-top-light mt-24 mb-24"></div>

                                            <div class="row y-gap-10 justify-between items-center">
                                                <div class="col-auto">
                                                    <div class="text-15 lh-12 fw-500">Children</div>

                                                </div>

                                                <div class="col-auto">
                                                    <div class="d-flex items-center js-counter" data-value-change=".js-count-child">
                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleChildrenDecrement}>
                                                            <i class="icon-minus text-12"></i>
                                                        </button>

                                                        <div class="flex-center size-20 ml-15 mr-15">
                                                            <div class="text-15 js-count">{children}</div>
                                                        </div>

                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleChildrenIncrement}>
                                                            <i class="icon-plus text-12"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="border-top-light mt-24 mb-24"></div>

                                            <div class="row y-gap-10 justify-between items-center">
                                                <div class="col-auto">
                                                    <div class="text-15 fw-500">Rooms</div>
                                                </div>

                                                <div class="col-auto">
                                                    <div class="d-flex items-center js-counter" data-value-change=".js-count-room">
                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-down" onClick={handleRoomsDecrement}>
                                                            <i class="icon-minus text-12"></i>
                                                        </button>

                                                        <div class="flex-center size-20 ml-15 mr-15">
                                                            <div class="text-15 js-count">{rooms}</div>
                                                        </div>

                                                        <button class="button -outline-blue-1 text-blue-1 size-38 rounded-4 js-up" onClick={handleRoomsIncrement}>
                                                            <i class="icon-plus text-12"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> : null
                                }

                            </div>

                            <div class="button-item">
                                <button class="mainSearch__submit button -dark-1 py-15 px-35 h-60 col-12 rounded-4 bg-blue-1 text-white" onClick={() => {
                                    Searchlist()

                                }}
                                >
                                    <i class="icon-search text-20 mr-10"></i>
                                    Search
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className="moreOption text-white">
                        <div className="selextbox">

                            <DropdownButton id="dropdown-basic-button" className="bg-arrowndown dropdown-basic-button2" title="Rating">
                                <i class="fa fa-angle-down" aria-hidden="true"></i>
                                <div className="form-check">
                                    <input className="form-check-input" type="checkbox" value="5" id="onestar5" onChange={handleRatingChange} />
                                    <label className="form-check-label" htmlFor="onestar5">
                                        5 Star
                                    </label>
                                </div>
                                <div className="form-check">
                                    <input className="form-check-input" type="checkbox" value="4" id="onestar4" onChange={handleRatingChange} />
                                    <label className="form-check-label" htmlFor="onestar4">
                                        4 Star
                                    </label>
                                </div>
                                <div className="form-check">
                                    <input className="form-check-input" type="checkbox" value="3" id="onestar3" onChange={handleRatingChange} />
                                    <label className="form-check-label" htmlFor="onestar3">
                                        3 Star
                                    </label>
                                </div>
                                <div className="form-check">
                                    <input className="form-check-input" type="checkbox" value="2" id="onestar2" onChange={handleRatingChange} />
                                    <label className="form-check-label" htmlFor="onestar2">
                                        2 Star
                                    </label>
                                </div>
                                <div className="form-check">
                                    <input className="form-check-input" type="checkbox" value="1" id="onestar" onChange={handleRatingChange} />
                                    <label className="form-check-label" htmlFor="onestar">
                                        1 Star
                                    </label>
                                </div>
                            </DropdownButton>
                        </div>
                        <div className="selextbox">

                            <select className="bg-arrowndown dropdown-basic-button2" onChange={handleCountryChange}>
                                <option>Netionality</option>
                                {Country.map((country, index) => (
                                    <option key={index}>{country.name}</option>
                                ))}
                            </select>
                        </div>
                        <div className="selextbox">

                            <select className="bg-arrowndown dropdown-basic-button2" onChange={handleChangeNationlity}>
                                <option>Country</option>
                                {Country.map((country, index) => (
                                    <option key={index}>{country.name}</option>
                                ))}
                            </select>
                        </div>
                        <div className="selextbox selectcheck">
                            <div className="form-check">
                                <input className="form-check-input" type="checkbox" defaultValue id="onestar" />
                                <label className="form-check-label" htmlFor="onestar">
                                    Special Category
                                </label>

                            </div>

                        </div>
                    </div>
                </div>
                </div>
                </section>
               <Footer />
            </main>
        </div>
    )
}

export default Hotel;

// THIS IS VERY IMPORTENT PART "MTAwMCA3Mzk5OTA" //