import React from "react";
import {Link} from 'react-router-dom';

const Navbar = () => {
  return (

    <div className="header-menu col-auto" data-x="mobile-menu" data-x-toggle="is-menu-active">
      <div className="mobile-overlay" />
      <div className="header-menu__content">
        <div className="mobile-bg js-mobile-bg" />
        <div className="menu js-navList d-flex justify-content-between">
          <ul className="menu__nav text-dark-1 -is-active text-center">
            <li><Link to="/Home"> Home</Link></li>
            <li><Link to="/"> Flight</Link></li>
            <li><Link to="/Hotel"> Hotal</Link></li>
            <li><Link to="/Destination"> Destination</Link></li>
            <li><Link to="/Tour"> Tour</Link></li>
            <li><Link to="/Contact">Contact</Link></li>
            <li><Link to="/Login">Login</Link></li>
            <li><Link to="/Register">Register</Link></li>
            

          </ul>


        </div>
       
      </div>

    </div>
  )
}
export default Navbar;